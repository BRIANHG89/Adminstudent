# quizzer-ajax
Versión ajax de la trivia web del blog
